# Copyright (C) 2021 By VeezMusicProject

from driver.queues import QUEUE
from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from config import (
    ASSISTANT_NAME,
    BOT_NAME,
    BOT_USERNAME,
    GROUP_SUPPORT,
    OWNER_NAME,
    UPDATES_CHANNEL,
)


@Client.on_callback_query(filters.regex("cbstart"))
async def cbstart(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""👀 **Hɪ [{query.message.chat.first_name}](tg://user?id={query.message.chat.id}) !**\n
💭 **[𝗠𝗲𝘁𝗶𝘄𝘇 𝗧𝗲𝗮𝗺 𝗣𝗹𝗮𝘆𝗲𝗿👻](https://t.me/{BOT_USERNAME}) Aʟʟᴏᴡs Yᴏᴜ Tᴏ Pʟᴀʏ Mᴜsɪᴄ Aɴᴅ Vɪᴅᴇᴏ Oɴ Gʀᴏᴜᴘs Tʜʀᴏᴜɢʜ Tʜᴇ Nᴇᴡ Tᴇʟᴇɢʀᴀᴍ's Vɪᴅᴇᴏ Cʜᴀᴛs!**

💡 **Fɪɴᴅ Oᴜᴛ Aʟʟ Tʜᴇ Bᴏᴛ's Cᴏᴍᴍᴀɴᴅs Aɴᴅ Hᴏᴡ Tʜᴇʏ Wᴏʀᴋ Bʏ Cʟɪᴄᴋɪɴɢ Oɴ Tʜᴇ » 🔻 Cᴏᴍᴍᴀɴᴅs Bᴜᴛᴛᴏɴ!**

🔖 **Tᴏ Kɴᴏᴡ Hᴏᴡ Tᴏ Usᴇ Tʜɪs Bᴏᴛ, Pʟᴇᴀsᴇ Cʟɪᴄᴋ Oɴ Tʜᴇ » 📄 Aᴅᴅ Mᴇ Hᴇʟᴘ Bᴜᴛᴛᴏɴ!**""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "🥂 Aᴅᴅ Mᴇ 🥂",
                        url=f"https://t.me/{BOT_USERNAME}?startgroup=true",
                    )
                ],
                [InlineKeyboardButton("📄 Aᴅᴅ Mᴇ Hᴇʟᴘ", callback_data="cbhowtouse")],
                [
                    InlineKeyboardButton("🔻 Cᴏᴍᴍᴀɴᴅs", callback_data="cbcmds"),
                    InlineKeyboardButton("👑 Cʀᴇᴀᴛᴏʀ", url=f"https://t.me/Metiwz"),
                ],
                [
                    InlineKeyboardButton(
                        "🌐 Oғғɪᴄɪᴀʟ Sɪᴛᴇ", url=f"https://Metiwz.ir"
                    ),
                    InlineKeyboardButton(
                        "📣 Oғғɪᴄɪᴀʟ Cʜᴀɴɴᴇʟ", url=f"https://t.me/Metiwz_Team"
                    ),
                ],
                [
                    InlineKeyboardButton(
                        "💎 Iɴsᴛᴀɢʀᴀᴍ & Tᴇʟᴇɢʀᴀᴍ Sᴇʀᴠɪᴄᴇs 💎", url="https://T.me/Metiwz"
                    )
                ],
            ]
        ),
        disable_web_page_preview=True,
    )


@Client.on_callback_query(filters.regex("cbhowtouse"))
async def cbguides(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""📄 **Aᴅᴅ Mᴇ Hᴇʟᴘ :**

1.) **Fɪʀsᴛ, Aᴅᴅ Mᴇ Tᴏ Yᴏᴜʀ Gʀᴏᴜᴘ.**
2.) **Tʜᴇɴ, Pʀᴏᴍᴏᴛᴇ Mᴇ As Aᴅᴍɪɴsᴛʀᴀᴛᴏʀ Aɴᴅ Gɪᴠᴇ Aʟʟ Pᴇʀᴍɪssɪᴏɴs Exᴄᴇᴘᴛ Aɴᴏɴʏᴍᴏᴜs Aᴅᴍɪɴ.**
3.) **Aғᴛᴇʀ Pʀᴏᴍᴏᴛɪɴɢ Mᴇ, Tʏᴘᴇ /reload Iɴ Gʀᴏᴜᴘ Tᴏ Rᴇғʀᴇsʜ Tʜᴇ Aᴅᴍɪɴ Dᴀᴛᴀ.**
3.) **Aᴅᴅ @{ASSISTANT_NAME} Tᴏ Yᴏᴜʀ Gʀᴏᴜᴘ Oʀ Tʏᴘᴇ /userbotjoin Tᴏ Iɴᴠɪᴛᴇ Hᴇʀ.**
4.) **Tᴜʀɴ Oɴ Tʜᴇ Vɪᴅᴇᴏ Cʜᴀᴛ Fɪʀsᴛ Bᴇғᴏʀᴇ Sᴛᴀʀᴛ Tᴏ Pʟᴀʏ Vɪᴅᴇᴏ/Mᴜsɪᴄ.**
5.) **Sᴏᴍᴇᴛɪᴍᴇs, Rᴇʟᴏᴀᴅɪɴɢ Tʜᴇ Bᴏᴛ Bʏ Usɪɴɢ /reload Cᴏᴍᴍᴀɴᴅ Cᴀɴ Hᴇʟᴘ Yᴏᴜ Tᴏ Fɪx Sᴏᴍᴇ Pʀᴏʙʟᴇᴍ.**

📌 **Iғ Tʜᴇ UsᴇʀBᴏᴛ Nᴏᴛ Jᴏɪɴᴇᴅ Tᴏ Vɪᴅᴇᴏ Cʜᴀᴛ, Mᴀᴋᴇ Sᴜʀᴇ Iғ Tʜᴇ Vɪᴅᴇᴏ Cʜᴀᴛ Aʟʀᴇᴀᴅʏ Tᴜʀɴᴇᴅ Oɴ, Oʀ Tʏᴘᴇ /userbotleave Tʜᴇɴ Tʏᴘᴇ /userbotjoin Aɢᴀɪɴ.**

⚡ __𝗖𝗼𝗱𝗲𝗱 𝗕𝘆 𝗠𝗲𝘁𝗶𝘄𝘇 𝗧𝗲𝗮𝗺__""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("➪ Gᴏ Bᴀᴄᴋ", callback_data="cbstart")]]
        ),
    )


@Client.on_callback_query(filters.regex("cbcmds"))
async def cbcmds(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""👀 **Hɪ [{query.message.chat.first_name}](tg://user?id={query.message.chat.id}) !**

» **Pʀᴇss Tʜᴇ Bᴜᴛᴛᴏɴ Bᴇʟᴏᴡ Tᴏ Rᴇᴀᴅ Tʜᴇ Exᴘʟᴀɴᴀᴛɪᴏɴ Aɴᴅ Sᴇᴇ Tʜᴇ Lɪsᴛ ᴏғ Aᴠᴀɪʟᴀʙʟᴇ Cᴏᴍᴍᴀɴᴅs !**

⚡ __𝗖𝗼𝗱𝗲𝗱 𝗕𝘆 𝗠𝗲𝘁𝗶𝘄𝘇 𝗧𝗲𝗮𝗺__""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("👷🏻 Aᴅᴍɪɴ Cᴍᴅ", callback_data="cbadmin"),
                    InlineKeyboardButton("🧙🏻 Sᴜᴅᴏ Cᴍᴅ", callback_data="cbsudo"),
                ],[
                    InlineKeyboardButton("📚 Bᴀsɪᴄ Cᴍᴅ", callback_data="cbbasic")
                ],[
                    InlineKeyboardButton("➪ Gᴏ Bᴀᴄᴋ", callback_data="cbstart")
                ],
            ]
        ),
    )


@Client.on_callback_query(filters.regex("cbbasic"))
async def cbbasic(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""🏮 Hᴇʀᴇ Is Tʜᴇ Bᴀsɪᴄ Cᴏᴍᴍᴀɴᴅs:

» /mplay (song name/link) - Pʟᴀʏ Mᴜsɪᴄ Oɴ Vᴏɪsᴇ Cʜᴀᴛ
» /vplay (video name/link) - Pʟᴀʏ Vɪᴅᴇᴏ Oɴ Vᴏɪᴄᴇ Cʜᴀᴛ
» /vstream - Pʟᴀʏ Lɪᴠᴇ Vɪᴅᴇᴏ Fʀᴏᴍ YT Lɪᴠᴇ/M3U8
» /playlist - Sʜᴏᴡ Yᴏᴜ Tʜᴇ Pʟᴀʏʟɪsᴛ
» /video (query) - Dᴏᴡɴʟᴏᴀᴅ Vɪᴅᴇᴏ Fʀᴏᴍ Yᴏᴜᴛᴜʙᴇ
» /song (query) - Dᴏᴡɴʟᴏᴀᴅ Sᴏɴɢ Fʀᴏᴍ Yᴏᴜᴛᴜʙᴇ
» /lyric (query) - Sᴄʀᴀᴘ Tʜᴇ Sᴏɴɢ Lʏʀɪᴄ
» /search (query) - Sᴇᴀʀᴄʜ A Yᴏᴜᴛᴜʙᴇ Vɪᴅᴇᴏ ʟɪɴᴋ

» /ping - Sʜᴏᴡ Tʜᴇ Bᴏᴛ Pɪɴɢ Sᴛᴀᴛᴜs
» /uptime - Sʜᴏᴡ Tʜᴇ Bᴏᴛ UᴘTɪᴍᴇ Sᴛᴀᴛᴜs
» /alive - Sʜᴏᴡ Tʜᴇ Bᴏᴛ Aʟɪᴠᴇ Iɴғᴏ (Iɴ Gʀᴏᴜᴘ)

⚡️ __𝗖𝗼𝗱𝗲𝗱 𝗕𝘆 𝗠𝗲𝘁𝗶𝘄𝘇 𝗧𝗲𝗮𝗺__""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("➪ Gᴏ Bᴀᴄᴋ", callback_data="cbcmds")]]
        ),
    )


@Client.on_callback_query(filters.regex("cbadmin"))
async def cbadmin(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""🏮 Hᴇʀᴇ Is Tʜᴇ Aᴅᴍɪɴ Cᴏᴍᴍᴀɴᴅs:

» /pause - Pᴀᴜsᴇ Tʜᴇ Sᴛʀᴇᴀᴍ
» /resume - Rᴇsᴜᴍᴇ Tʜᴇ Sᴛʀᴇᴀᴍ
» /skip - Sᴡɪᴛᴄʜ Tᴏ Nᴇxᴛ Sᴛʀᴇᴀᴍ
» /stop - Sᴛᴏᴘ Tʜᴇ Sᴛʀᴇᴀᴍɪɴɢ
» /vmute - Mᴜᴛᴇ Tʜᴇ UsᴇʀBᴏᴛ Oɴ Vᴏɪᴄᴇ Cʜᴀᴛ
» /vunmute - Uɴᴍᴜᴛᴇ Tʜᴇ UsᴇʀBᴏᴛ Oɴ Vᴏɪᴄᴇ Cʜᴀᴛ
» /volume `1-200` - Aᴅᴊᴜsᴛ Tʜᴇ Vᴏʟᴜᴍᴇ Oғ Mᴜsɪᴄ (Usᴇʀʙᴏᴛ Mᴜsᴛ Bᴇ Aᴅᴍɪɴ)
» /reload - Rᴇʟᴏᴀᴅ Bᴏᴛ Aɴᴅ Rᴇғʀᴇsʜ Tʜᴇ Aᴅᴍɪɴ Dᴀᴛᴀ
» /userbotjoin - Iɴᴠɪᴛᴇ UsᴇʀBᴏᴛ Tᴏ Jᴏɪɴ Gʀᴏᴜᴘ
» /userbotleave - Oʀᴅᴇʀ UsᴇʀBᴏᴛ Tᴏ Lᴇᴀᴠᴇ Gʀᴏᴜᴘ

⚡️ __𝗖𝗼𝗱𝗲𝗱 𝗕𝘆 𝗠𝗲𝘁𝗶𝘄𝘇 𝗧𝗲𝗮𝗺__""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("➪ Gᴏ Bᴀᴄᴋ", callback_data="cbcmds")]]
        ),
    )

@Client.on_callback_query(filters.regex("cbsudo"))
async def cbsudo(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""🏮 Hᴇʀᴇ Is Tʜᴇ Sᴜᴅᴏ Cᴏᴍᴍᴀɴᴅs:

» /rmw - cCʟᴇᴀɴ Aʟʟ Rᴀᴡ Fɪʟᴇs
» /rmd - Cʟᴇᴀɴ Aʟʟ Dᴏᴡɴʟᴏᴀᴅ Fɪʟᴇs
» /sysinfo - Sʜᴏᴡ Tʜᴇ Sʏsᴛᴇᴍ Iɴғᴏʀᴍᴀᴛɪᴏɴ
» /update - Uᴘᴅᴀᴛᴇ Yᴏᴜʀ Bᴏᴛ Tᴏ Lᴀᴛᴇsᴛ Vᴇʀsɪᴏɴ
» /restart - Rᴇsᴛᴀʀᴛ Yᴏᴜʀ Bᴏᴛ
» /leaveall - Oʀᴅᴇ UsᴇʀBᴏᴛ Tᴏ Lᴇᴀᴠᴇ Fʀᴏᴍ Aʟʟ Gʀᴏᴜᴘs

⚡ __𝗖𝗼𝗱𝗲𝗱 𝗕𝘆 𝗠𝗲𝘁𝗶𝘄𝘇 𝗧𝗲𝗮𝗺__""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("➪ Gᴏ Bᴀᴄᴋ", callback_data="cbcmds")]]
        ),
    )


@Client.on_callback_query(filters.regex("cbmenu"))
async def cbmenu(_, query: CallbackQuery):
    if query.message.sender_chat:
        return await query.answer("Yᴏᴜ' Rᴇ Aɴ Aɴᴏɴʏᴍᴏᴜs Aᴅᴍɪɴ !\n\n» Rᴇᴠᴇʀᴛ Bᴀᴄᴋ Tᴏ Usᴇʀ Aᴄᴄᴏᴜɴᴛ Fʀᴏᴍ Aᴅᴍɪɴ Rɪɢʜᴛs.")
    a = await _.get_chat_member(query.message.chat.id, query.from_user.id)
    if not a.can_manage_voice_chats:
        return await query.answer("💡 Oɴʟʏ Aᴅᴍɪɴ Wɪᴛʜ Mᴀɴᴀɢᴇ Vᴏɪᴄᴇ Cʜᴀᴛ Pᴇʀᴍɪssɪᴏɴ Tʜᴀᴛ Cᴀɴ Tᴀᴘ Tʜɪs Bᴜᴛᴛᴏɴ !", show_alert=True)
    chat_id = query.message.chat.id
    if chat_id in QUEUE:
          await query.edit_message_text(
              f"⚙️ **Sᴇᴛᴛɪɴɢ Oғ** {query.message.chat.title}\n\n⏸ : Pᴀᴜsᴇ Sᴛʀᴇᴀᴍ\n▶️ : Rᴇsᴜᴍᴇ Sᴛʀᴇᴀᴍ\n🔇 : Mᴜᴛᴇ UsᴇʀBᴏᴛ\n🔊 : Uɴᴍᴏᴛᴇ UsᴇʀBᴏᴛ\n⏹ : Sᴛᴏᴘ Sᴛʀᴇᴀᴍ",
              reply_markup=InlineKeyboardMarkup(
                  [[
                      InlineKeyboardButton("⏹", callback_data="cbstop"),
                      InlineKeyboardButton("⏸", callback_data="cbpause"),
                      InlineKeyboardButton("▶️", callback_data="cbresume"),
                  ],[
                      InlineKeyboardButton("🔇", callback_data="cbmute"),
                      InlineKeyboardButton("🔊", callback_data="cbunmute"),
                  ],[
                      InlineKeyboardButton("🗑 Cʟᴏsᴇ", callback_data="cls")],
                  ]
             ),
         )
    else:
        await query.answer("❌ Nᴏᴛʜɪɴɢ Is Cᴜʀʀᴇɴᴛʟʏ Sᴛʀᴇᴀᴍɪɴɢ", show_alert=True)


@Client.on_callback_query(filters.regex("cls"))
async def close(_, query: CallbackQuery):
    a = await _.get_chat_member(query.message.chat.id, query.from_user.id)
    if not a.can_manage_voice_chats:
        return await query.answer("💡 Oɴʟʏ Aᴅᴍɪɴ Wɪᴛʜ Mᴀɴᴀɢᴇ Vᴏɪᴄᴇ Cʜᴀᴛs Pᴇʀᴍɪssɪᴏɴ Tʜᴀᴛ Cᴀɴ Tᴀᴘ Tʜɪs Bᴜᴛᴛᴏɴ !", show_alert=True)
    await query.message.delete()
